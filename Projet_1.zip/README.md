L’objectif de ce premier projet est de vous donner toutes les clés pour réussir votre parcours, puis votre insertion professionnelle en tant que développeur.

Ainsi, vous allez définir votre planning de formation et vous familiariser avec les projets que vous aurez à réaliser pendant votre parcours. Ce projet vous permettra également de vous tenir informé des nouveautés de votre futur domaine d’activité. Enfin, vous ferez vos premiers pas en programmation en créant votre première page Web.

Par la suite, le format des projets sera totalement différent ! Vous serez immergé dans le monde professionnel et réaliserez des livrables comme dans la vraie vie d’un développeur.
